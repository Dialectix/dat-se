import os
from datetime import datetime
from openai import AzureOpenAI

# Initialize Azure OpenAI client using App Service environment variables
client = AzureOpenAI(
    api_key=os.environ.get("AZURE_OPENAI_API_KEY"),
    api_version=os.environ.get("OPENAI_API_VERSION"),
    azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT")
)

def enforce_step_1_epistemic_check(user_input: str) -> str:
    """
    Adds a disambiguation note if base-10 logic or arithmetic is detected.
    """
    arithmetic_terms = ["+", "-", "*", "/", "=", "==", "!=", "<", ">"]
    if any(op in user_input for op in arithmetic_terms):
        return (
            "NOTE: The input appears to rely on base-10 arithmetic or logical identity. "
            "Before proceeding, you MUST assess the ontological and epistemic meaning of each element "
            "(e.g., '1', '+', '=', etc.). Do not resolve this as a mathematical fact until contradictions "
            "across symbolic, quantum, phenomenological, and social frameworks have been explored.\n\n"
        )
    return ""

def ask_gpt(prompt: str) -> str:
    """
    Submits a prompt to Azure OpenAI and returns the assistant's reply.
    """
    try:
        deployment_name = os.environ.get("AZURE_OPENAI_DEPLOYMENT")
        print(f"🔍 Using deployment: {deployment_name}")

        response = client.chat.completions.create(
            model=deployment_name,  # ✅ Required key for AzureOpenAI SDK
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a dialectical reasoning engine. Respond only in the following format:\n\n"
                        "### Step 1: Ontological and Epistemic Disambiguation\n...\n\n"
                        "### Step 2: Dialectical Tension (Thesis, Antithesis, Synthesis)\n...\n\n"
                        "### Step 3: Contextual Evaluation\n...\n\n"
                        "### Step 4: Structured Resolution\n...\n\n"
                        "### Reformulated Question\n..."
                    )
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )

        message = response.choices[0].message.content
        return message.strip() if message else "ERROR: Empty response."

    except Exception as e:
        return f"ERROR: {str(e)}"

def run_dat_pipeline(user_input: str) -> dict:
    """
    Builds the DAT prompt and returns raw GPT output for debugging.
    """
    disambiguation_note = enforce_step_1_epistemic_check(user_input)

    full_prompt = f"""
You are a dialectical reasoning engine.

{disambiguation_note}
You must apply the full Dialectical Analysis Theory (DAT) 4-step method to the input provided.
IMPORTANT:
- You MUST NOT skip or compress any step.
- You may NOT proceed to Step 2 (Dialectical Tension) unless Step 1 finds a contradiction.
- You may NOT resolve any argument in Step 4 unless it has been transformed or recontextualized in Step 3.
- Numeric/logical assertions (e.g., "1 + 1 = 2") must be ontologically disambiguated across symbolic, phenomenological, social, and quantum modes before resolution.

Analyze the following input using the Dialectical Analysis Theory (DAT) 4-step method.
Input:
\"\"\"{user_input}\"\"\"

Respond using this exact format:

### Step 1: Ontological and Epistemic Disambiguation
...

### Step 2: Dialectical Tension (Thesis, Antithesis, Synthesis)
...

### Step 3: Contextual Evaluation
...

### Step 4: Structured Resolution
(This MUST be a distinct and standalone paragraph that clearly completes the dialectic.)

### Reformulated Question
...

### Illustrative Example
Provide a single brief example (real-world, symbolic, philosophical, etc.) that illustrates the reformulated question. If no valid example can be given, explain why.
"""

    response = ask_gpt(full_prompt)

    return {
        "raw_response": response,
        "timestamp": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    }
