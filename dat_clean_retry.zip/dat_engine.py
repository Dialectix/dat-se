from datetime import datetime
from gpt_executor import ask_gpt
import re

def run_dat_pipeline(user_input, max_retries=2):
    def build_prompt(text):
        return f"""
You are a dialectical reasoning engine.

Process the following input using a four-step dialectical method. You MUST include all four steps clearly labeled using the exact headers below. Do not merge or omit any section.

Input:
\"\"\"{text}\"\"\"

Respond using this format:

### Step 1: Ontological and Epistemic Disambiguation
...

### Step 2: Dialectical Tension (Thesis, Antithesis, Synthesis)
...

### Step 3: Contextual Evaluation
...

### Step 4: Structured Resolution
(This MUST be a distinct and standalone paragraph that clearly completes the dialectic.)

### Reformulated Question
...

Before finishing, double-check that all 5 headings are included and nothing is skipped.
"""

    def extract_sections(raw):
        steps = {
            "step1_summary": "Step 1 missing.",
            "step2_summary": "Step 2 missing.",
            "step3_summary": "Step 3 missing.",
            "step4_summary": "Step 4 missing.",
            "final_output": "Reformulated Question — Reformulated question not clearly returned.",
            "timestamp": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        }
        if not isinstance(raw, str) or not raw.strip():
            return steps, False

        parts = re.split(r"###\s*(Step 1|Step 2|Step 3|Step 4|Reformulated Question):?", raw)
        label_map = {
            "Step 1": "step1_summary",
            "Step 2": "step2_summary",
            "Step 3": "step3_summary",
            "Step 4": "step4_summary",
            "Reformulated Question": "final_output"
        }
        for i in range(1, len(parts), 2):
            label = parts[i].strip()
            text = parts[i + 1].strip()
            key = label_map.get(label)
            if key:
                steps[key] = text

        # Fallback for Step 4
        if steps["step4_summary"].startswith("Step 4 missing."):
            match = re.search(r'(Structured Resolution[\s\S]+?)(?=###|\Z)', raw, re.IGNORECASE)
            if match:
                steps["step4_summary"] = "(Extracted fallback)\n" + match.group(1).strip()

        # Fallback for final question
        if "not clearly returned" in steps["final_output"]:
            for line in reversed(raw.splitlines()):
                if "?" in line and len(line.strip().split()) > 4:
                    steps["final_output"] = f'Reformulated Question — "{line.strip()}"'
                    break

        is_complete = all("missing" not in v.lower() for k, v in steps.items() if k.startswith("step"))
        return steps, is_complete

    for attempt in range(max_retries + 1):
        raw_response = ask_gpt(build_prompt(user_input))
        structured, ok = extract_sections(raw_response)
        if ok:
            return structured

    return structured  # Return last attempt even if partial
