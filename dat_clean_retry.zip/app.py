from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dat_engine import run_dat_pipeline

app = FastAPI()

# CORS settings — adjust if needed
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://agreeable-field-063a7a703.6.azurestaticapps.net",  # Your deployed frontend
        "http://localhost:5173"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "DAT engine API is running."}

class AnalyzeRequest(BaseModel):
    text: str

@app.post("/analyze")
async def analyze_question(request: AnalyzeRequest):
    user_input = request.text.strip()

    if not user_input:
        return {"error": "Please enter a question."}

    try:
        result = run_dat_pipeline(user_input)

        if "error" in result:
            return {"error": result["error"]}

        # Wrap for frontend structure
        return {"response": result}

    except Exception as e:
        return {"error": f"Internal server error: {str(e)}"}
